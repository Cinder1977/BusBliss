const SYMBOLS_DICT = {}; const TOKENS_DICT = {};var layersData =  [
 {
  "c": [
   {
    "x": 0,
    "y": 0,
    "w": 390,
    "h": 844,
    "ii": 0,
    "n": "Home Page",
    "tp": "ShapePath",
    "c": [
     {
      "x": -10,
      "y": 0,
      "w": 400,
      "h": 44,
      "ii": 1,
      "n": "Group 9",
      "tp": "Group",
      "c": [
       {
        "x": -10,
        "y": 0,
        "w": 400,
        "h": 44,
        "ii": 2,
        "n": "Group 10",
        "tp": "Group",
        "c": [
         {
          "x": -10,
          "y": 0,
          "w": 400,
          "h": 44,
          "ii": 3,
          "n": "iPhone Status bar",
          "tp": "Symbol",
          "c": [
           {
            "x": 314,
            "y": 17,
            "w": 18,
            "h": 13,
            "ii": 4,
            "n": "wifi",
            "tp": "ShapePath",
            "pr": "background-color: #ffffff;\n"
           },
           {
            "x": 337,
            "y": 17,
            "w": 26.602563858032227,
            "h": 12.5,
            "ii": 5,
            "n": "_battery",
            "tp": "Symbol",
            "c": [
             {
              "x": 338.923095703125,
              "y": 18.923095703125,
              "w": 20.19230842590332,
              "h": 8.653846740722656,
              "ii": 6,
              "n": "fill",
              "tp": "ShapePath",
              "pr": "background-color: #ffffff;\n"
             }
            ],
            "s": "_battery"
           },
           {
            "x": 29,
            "y": 15,
            "w": 45,
            "h": 18,
            "ii": 7,
            "n": "time",
            "tp": "Text",
            "tx": "19:02",
            "pr": "font-family: SF Pro Display;\nfont-size: 18px;\nfont-weight: 600;\nline-height: 100%;\ntext-transform: none;\nletter-spacing: -2%;\n-pt-paragraph-spacing: 0;\nbackground-color: #ffffff;\n"
           }
          ],
          "s": "Theme=Dark, Notch=True, Call in=False, Wifi=True, Back=False"
         }
        ]
       }
      ]
     },
     {
      "x": 102,
      "y": 86,
      "w": 182,
      "h": 60,
      "ii": 8,
      "n": "Frame 7",
      "tp": "ShapePath",
      "c": [],
      "pr": ""
     },
     {
      "x": 75,
      "y": 91,
      "w": 240,
      "h": 700,
      "ii": 9,
      "n": "Group 2",
      "tp": "Group",
      "c": [
       {
        "x": 117,
        "y": 91,
        "w": 157,
        "h": 40,
        "ii": 10,
        "n": "Bus Bliss",
        "tp": "Text",
        "tx": "Bus Bliss",
        "pr": "font-family: Roboto;\nfont-size: 40px;\nfont-weight: 400;\nline-height: 100%;\ntext-transform: none;\nletter-spacing: -2%;\n-pt-paragraph-spacing: 0;\nbackground-color: #6ec950;\n"
       },
       {
        "x": 75,
        "y": 752,
        "w": 240,
        "h": 39,
        "ii": 11,
        "n": "Rectangle 5",
        "tp": "ShapePath",
        "pr": " border-radius : 5px;\nborder-color: #000000;\nborder-width : 2px;\nbackground-color: #6ec950;\n"
       },
       {
        "x": 119,
        "y": 762,
        "w": 152,
        "h": 25.350000381469727,
        "ii": 12,
        "n": "Route Selector",
        "tp": "Text",
        "tx": "Route Selector",
        "pr": "font-family: Roboto;\nfont-size: 20px;\nfont-weight: 400;\nline-height: 100%;\ntext-transform: none;\nletter-spacing: -2%;\n-pt-paragraph-spacing: 0;\nbackground-color: #242223;\n"
       }
      ]
     },
     {
      "x": 75,
      "y": 681,
      "w": 240,
      "h": 39,
      "ii": 13,
      "n": "Group 10",
      "tp": "Group",
      "c": [
       {
        "x": 75,
        "y": 681,
        "w": 240,
        "h": 39,
        "ii": 14,
        "n": "Rectangle 5",
        "tp": "ShapePath",
        "pr": " border-radius : 5px;\nborder-color: #6ec950;\nborder-width : 2px;\nbackground-color: #6ec950;\n"
       },
       {
        "x": 119,
        "y": 691,
        "w": 152,
        "h": 25.350000381469727,
        "ii": 15,
        "n": "Trip Planner",
        "tp": "Text",
        "tx": "Trip Planner",
        "pr": "font-family: Roboto;\nfont-size: 20px;\nfont-weight: 400;\nline-height: 100%;\ntext-transform: none;\nletter-spacing: -2%;\n-pt-paragraph-spacing: 0;\nbackground-color: #242223;\n"
       }
      ]
     },
     {
      "x": 201,
      "y": 840.9315185546875,
      "w": 365.136962890625,
      "h": 0,
      "ii": 16,
      "n": "Arrow 2",
      "tp": "ShapePath",
      "pr": "border-color: #000000;\nborder-width : 3px;\n"
     },
     {
      "x": 331,
      "y": 844,
      "w": 57,
      "h": 0,
      "ii": 17,
      "n": "Arrow 9",
      "tp": "ShapePath",
      "pr": "border-color: #000000;\nborder-width : 3px;\n"
     },
     {
      "x": 75,
      "y": 393,
      "w": 240,
      "h": 169,
      "ii": 18,
      "n": "AdobeStock_204873595",
      "tp": "ShapePath",
      "pr": " border-radius : 5px;\n"
     },
     {
      "x": 53,
      "y": 109,
      "w": 279,
      "h": 259,
      "ii": 19,
      "n": "Group 18",
      "tp": "Group",
      "c": [
       {
        "x": 53,
        "y": 109,
        "w": 279,
        "h": 259,
        "ii": 20,
        "n": "AdobeStock_507631013 (1)_thumbnail (1) 1",
        "tp": "ShapePath",
        "pr": "border-color: #ffffff00;\nborder-width : 1px;\n"
       }
      ]
     },
     {
      "x": 0,
      "y": 43,
      "w": 3,
      "h": 1,
      "ii": 21,
      "n": "Rectangle 37",
      "tp": "ShapePath",
      "pr": "background-color: #d9d9d9;\n"
     }
    ],
    "pr": "border-color: #242223;\nborder-width : 3px;\nbackground-color: #242223;\n"
   }
  ]
 }
]