var story = {
 "docName": "Bus Bliss Wireframing",
 "docPath": "P_P_P",
 "docVersion": "V_V_V",
 "ownerName": "",
 "ownerEmail": "",
 "authorName": "V_V_N",
 "authorEmail": "V_V_E",
 "commentsURL": "V_V_C",
 "hasRetina": true,
 "serverToolsPath": "",
 "fontSizeFormat": -1,
 "fileType": "png",
 "disableInteractions": false,
 "disableHotspots": false,
 "hideGallery": false,
 "zoomEnabled": true,
 "title": "Demo",
 "layersExist": true,
 "highlightLinks": true,
 "pages": [
  {
   "id": "263:502",
   "groupID": "0:1",
   "transAnimType": 0,
   "title": "Bus Bliss Home",
   "image": "bus-bliss-home.png",
   "image2x": "bus-bliss-home@2x.png",
   "index": 0,
   "width": 390,
   "height": 844,
   "x": -965,
   "y": -2431,
   "type": "regular",
   "fixedPanels": [],
   "links": [],
   "overlayPinPage": 6,
   "overlayOutsideClickIgnore": true,
   "layout": null
  }
 ],
 "groups": [
  {
   "id": "0:1",
   "name": "Page 1"
  }
 ],
 "startPageIndex": 0,
 "totalImages": 1,
 "backColor": "#FFFFFF"
}